interface HighScore {
    [key: string]: string;
}

interface ScoreData {
    name: string;
    score: number;
}
