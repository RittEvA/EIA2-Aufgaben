namespace Endabgabe {

    export class Objekt {
        x: number;
        y: number;
        s: number;//zur Skalierung vom Fisch des Spielers
        t: number;//für die Kathegorisierung von Fischen um zu kontrollieren

        constructor() {

        }
        draw(): void {
            //
        }
        update() {
            //
        }
    }
}