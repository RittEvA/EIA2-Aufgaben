var Endabgabe;
(function (Endabgabe) {
    class Objekt {
        constructor() {
        }
        draw() {
            //
        }
        update() {
            //
        }
    }
    Endabgabe.Objekt = Objekt;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Objekt.js.map